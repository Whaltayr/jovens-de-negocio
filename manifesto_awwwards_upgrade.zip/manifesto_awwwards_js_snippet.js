
/* ============================================
   Adicionar dentro de initSectionMotion() ou chamar à parte
   ============================================ */
function initManifestoMotion() {
  if (prefersReducedMotion || !hasGSAP) return;

  const section = document.querySelector('.manifesto--enhanced');
  if (!section) return;

  const bgImg = section.querySelector('.manifesto__bg img');
  const mainCard = section.querySelector('.manifesto-card--main');
  const smallCard = section.querySelector('.manifesto-card--small');
  const chip = section.querySelector('.manifesto-chip--quote');

  if (bgImg) {
    gsap.to(bgImg, {
      yPercent: 8,
      scale: 1.1,
      ease: 'none',
      scrollTrigger: {
        trigger: section,
        start: 'top bottom',
        end: 'bottom top',
        scrub: true
      }
    });
  }

  if (mainCard) {
    gsap.fromTo(mainCard,
      { opacity: 0, x: 46, rotate: -4 },
      {
        opacity: 1,
        x: 0,
        rotate: -2.2,
        duration: .9,
        ease: 'power3.out',
        scrollTrigger: { trigger: section, start: 'top 78%', once: true }
      }
    );
  }

  if (smallCard) {
    gsap.fromTo(smallCard,
      { opacity: 0, x: -40, rotate: 8 },
      {
        opacity: 1,
        x: 0,
        rotate: 5,
        duration: .86,
        delay: .08,
        ease: 'power3.out',
        scrollTrigger: { trigger: section, start: 'top 78%', once: true }
      }
    );
  }

  if (chip) {
    gsap.fromTo(chip,
      { opacity: 0, y: 22 },
      {
        opacity: 1,
        y: 0,
        duration: .7,
        ease: 'power3.out',
        scrollTrigger: { trigger: section, start: 'top 80%', once: true }
      }
    );
  }
}

/* E chama assim no DOMContentLoaded:
initManifestoMotion();
*/
