A nossa história — upgrade inspirado em padrões vistos no Awwwards

O que foi aplicado:
- background image suave atrás da secção;
- camada de grain/noise;
- grid discreto para textura;
- collage editorial com 2 fotos + 2 formas/flutuantes;
- composição que preenche o espaço em branco sem poluir;
- pronto para animar com ScrollTrigger.

Arquivos:
- manifesto_awwwards_section.html -> só a secção HTML
- manifesto_awwwards_patch.css -> patch CSS só desta secção
- manifesto_awwwards_js_snippet.js -> snippet opcional para animar a secção
- index_manifesto_awwwards.html -> HTML completo com a secção já trocada
- styles_manifesto_awwwards.css -> CSS completo + patch

Como usar:
1) Troca só a secção MANIFESTO no HTML.
2) Cola manifesto_awwwards_patch.css no fim do teu styles.css.
3) Se quiseres motion extra, adiciona o conteúdo de manifesto_awwwards_js_snippet.js ao teu script GSAP.
