Correção cirúrgica — Jovens do Valor

Arquivos:
- index_surgical_fixed.html
- styles_surgical_fixed.css
- script_surgical_fixed.js
- surgical_patch.css

Aplicação recomendada:
1. index_surgical_fixed.html -> index.html
2. styles_surgical_fixed.css -> styles.css
3. script_surgical_fixed.js -> script.js

O que foi feito:
- corrigido typo do CSS: --fs-h1 tinha 'a1.6rem'
- melhorado o estado do menu mobile sem redesenhar a navbar inteira
- aria-hidden/role/aria-modal no menu mobile
- sr-only no botão hamburger
- menu abre/fecha, bloqueia scroll, fecha com ESC e atualiza aria-label
- hero mantém split, mas agora com entrada esquerda/direita via GSAP
- sliders mantêm drag e botões com disabled real
