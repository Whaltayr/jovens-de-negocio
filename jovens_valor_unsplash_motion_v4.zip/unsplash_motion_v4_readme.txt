JOVENS DO VALOR — GSAP Motion v4.1 + imagens Unsplash

Aplicação recomendada:
1. index_unsplash_motion_v4.html -> index.html
2. styles_unsplash_motion_v4.css -> styles.css
3. script_unsplash_motion_v4.js -> script.js

O que foi repetido/melhorado:
- Mesmo foco do GSAP v4.
- Hero com entrada esquerda/direita.
- ScrollTrigger por secção.
- Valores com imagem + texto dentro do card.
- Como atuamos com imagem à esquerda e conteúdo à direita.
- Sliders preservados.
- Adicionadas imagens remotas de exemplo do Unsplash.

Importante:
As imagens estão em links remotos images.unsplash.com.
Para produção, o ideal é baixar/substituir por imagens locais:
- assets/images/hero/hero2.jpeg
- images/valores/*.jpg
- images/atuacao/*.jpg
